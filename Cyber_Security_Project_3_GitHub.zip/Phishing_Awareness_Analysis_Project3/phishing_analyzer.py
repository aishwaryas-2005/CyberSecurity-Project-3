import re

# Educational, rule-based phishing awareness analyzer.
# It NEVER opens or visits URLs.

SUSPICIOUS_KEYWORDS = [
    "urgent", "immediately", "verify", "verification", "suspended",
    "account locked", "click here", "act now", "confirm your password",
    "login", "security alert", "winner", "prize", "refund", "otp"
]

URGENCY_WORDS = ["urgent", "immediately", "act now", "within 24 hours", "expires today"]
CREDENTIAL_WORDS = ["password", "otp", "pin", "login", "username", "credentials"]
THREAT_WORDS = ["suspended", "blocked", "locked", "terminated", "deactivated"]

def extract_urls(text):
    return re.findall(r"https?://[^\s<>\"]+|www\.[^\s<>\"]+", text, re.I)

def analyze_message(text):
    lower = text.lower()
    urls = extract_urls(text)
    red_flags = []
    score = 0

    found_keywords = [word for word in SUSPICIOUS_KEYWORDS if word in lower]

    if found_keywords:
        red_flags.append("Suspicious keywords: " + ", ".join(found_keywords))
        score += min(3, len(found_keywords))

    if urls:
        red_flags.append(f"Contains {len(urls)} link(s); verify the domain before clicking.")
        score += 2

        for url in urls:
            if re.search(r"@", url):
                red_flags.append("A URL contains '@', which can hide the real destination.")
                score += 2
            if re.search(r"(bit\.ly|tinyurl|t\.co|goo\.gl|shorturl)", url, re.I):
                red_flags.append("A URL shortener is present; the final destination is hidden.")
                score += 2
            if "http://" in url.lower():
                red_flags.append("A link uses HTTP instead of HTTPS.")
                score += 1

    if any(word in lower for word in URGENCY_WORDS):
        red_flags.append("Uses urgency or pressure to force quick action.")
        score += 2

    if any(word in lower for word in CREDENTIAL_WORDS):
        red_flags.append("Requests or references sensitive login information.")
        score += 2

    if any(word in lower for word in THREAT_WORDS):
        red_flags.append("Uses threats such as account suspension or blocking.")
        score += 2

    if re.search(r"\b(dear customer|dear user|valued customer)\b", lower):
        red_flags.append("Uses a generic greeting instead of identifying the recipient.")
        score += 1

    if score >= 7:
        risk = "HIGH"
    elif score >= 4:
        risk = "MEDIUM"
    else:
        risk = "LOW"

    return risk, score, urls, red_flags

def main():
    print("=" * 60)
    print("PHISHING AWARENESS ANALYZER")
    print("=" * 60)
    print("Educational tool: URLs are detected but NEVER opened.")
    print()

    message = input("Paste the email/message to analyze:\n> ")

    risk, score, urls, red_flags = analyze_message(message)

    print("\n--- ANALYSIS RESULT ---")
    print(f"Risk level : {risk}")
    print(f"Risk score : {score}")
    print(f"Links found: {len(urls)}")

    if urls:
        for url in urls:
            print(f"  - {url}")

    print("\nRed flags:")
    if red_flags:
        for i, flag in enumerate(red_flags, 1):
            print(f"{i}. {flag}")
    else:
        print("No obvious rule-based red flags were detected.")

    print("\nWhy it may be unsafe:")
    if risk == "HIGH":
        print("The message contains multiple phishing indicators. Do not click links,")
        print("share credentials/OTP, or respond. Verify through an official channel.")
    elif risk == "MEDIUM":
        print("The message contains some suspicious indicators. Verify the sender")
        print("and destination independently before taking action.")
    else:
        print("No major indicators were detected by these rules. Still verify")
        print("unexpected requests and never share passwords or OTPs.")

if __name__ == "__main__":
    main()
