# Phishing Awareness Analysis – Project 3

## 1. Objective
The objective is to analyze sample messages and identify phishing attempts by detecting suspicious links, keywords, red flags, and unsafe behavior.

## 2. Approach
The program uses a simple rule-based approach:
1. Accept a message from the user.
2. Extract URLs without opening them.
3. Search for phishing-related keywords.
4. Detect urgency, threats, credential requests, generic greetings, URL shorteners, and HTTP links.
5. Calculate a simple risk score.
6. Classify the message as LOW, MEDIUM, or HIGH risk.
7. Display the detected red flags and safety advice.

## 3. Sample findings

### Message 1
**Indicator:** Account suspension + urgent verification + password request + HTTP link.

**Risk:** HIGH

**Why unsafe:** The message pressures the recipient to act quickly and requests sensitive information through a link.

### Message 2
**Indicator:** Prize claim + shortened URL.

**Risk:** HIGH

**Why unsafe:** Unexpected prize messages are a common social-engineering technique, and shortened URLs hide the final destination.

### Message 3
**Indicator:** Normal meeting notification.

**Risk:** LOW

**Why:** No obvious phishing indicators are present in this sample.

### Message 4
**Indicator:** Security alert + OTP/login request + urgency.

**Risk:** HIGH

**Why unsafe:** OTPs and login details are sensitive credentials and should not be shared through unsolicited messages.

## 4. Recommended countermeasures
- Do not click suspicious links.
- Verify the sender using an official website or known contact method.
- Never share passwords, PINs, or OTPs.
- Be careful with urgent threats and prize/refund claims.
- Hover over links where possible and inspect the actual domain.
- Report suspicious messages to the appropriate security team/provider.

## 5. Limitations
This is a basic educational, rule-based analyzer. A low-risk result does not prove that a message is safe. Real-world phishing detection may also require sender authentication, domain reputation, URL analysis, attachment scanning, and machine-learning techniques.

## 6. Conclusion
The project demonstrates how simple threat-identification rules can help users recognize common phishing indicators. It supports the project's goal of improving phishing awareness through practical analysis.
